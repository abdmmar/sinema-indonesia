import "./styles/style-tw.css";
import main from "./script/view/main.js";
import 'regenerator-runtime/runtime';

document.addEventListener(`DOMContentLoaded`, main); 